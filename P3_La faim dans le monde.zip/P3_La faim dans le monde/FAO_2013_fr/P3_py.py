# -*- coding: utf-8 -*-
"""
Created on Thu Oct 22 11:49:59 2020

@author: Utilisateur
"""





import pandas as pd
filepath = 'C:/Users/HP/Desktop/P3_NGUYEN_Quoc Vuong/FAO_2013_fr/fr_population.csv'
df_population = pd.read_csv(filepath)


print(len(list(set(df_population['Code zone']))))
print(len(list(set(df_population['Zone']))))
print(len(list(set(df_population['Valeur']))))


df_population = df_population.drop_duplicates(subset=None, keep='first', inplace=False, ignore_index=False)
indexdrop = df_population[df_population['Zone'] == 'Chine' ].index
df_population = df_population.drop(indexdrop , inplace=False)

pop_mondiale_2013 = df_population['Valeur'].sum() * 1000

print(pop_mondiale_2013)

#Q2
a1 = 38614
a2 = 2055
a3 = 1131
a4 = 21502
b1 = 20298
c1 = 7822
c2 = 748
c3 = 358
c4 = 1575
c5 = 2824
c6 = 6971

print(a1+a2+a3-a4)
print(b1)
print( c1+c2+c3+c4+c5+c6) 

#Q3
import pandas as pd
filepath = 'C:/Users/HP/Desktop/P3_NGUYEN_Quoc Vuong/FAO_2013_fr/fr_population.csv'
filepath1 = 'C:/Users/HP/Desktop/P3_NGUYEN_Quoc Vuong/FAO_2013_fr/fr_vegetaux.csv'
filepath2 = 'C:/Users/HP/Desktop/P3_NGUYEN_Quoc Vuong/FAO_2013_fr/fr_animaux.csv'
filepath3 = 'C:/Users/HP/Desktop/P3_NGUYEN_Quoc Vuong/FAO_2013_fr/fr_cereales.csv'
df_population = pd.read_csv(filepath)
df_vegetaux = pd.read_csv(filepath1)
df_animaux = pd.read_csv(filepath2)
df_cereales = pd.read_csv(filepath3)

import numpy as np
df_population = df_population.replace(0,np.nan)
df_vegetaux = df_vegetaux.replace(0, np.nan)
df_animaux = df_animaux.replace(0, np.nan)
df_cereales = df_cereales.replace(0, np.nan)

indexdrop = df_vegetaux[df_vegetaux['Zone'] == 'Chine' ].index
df_vegetaux = df_vegetaux.drop(indexdrop , inplace=False)
df_vegetaux = df_vegetaux.drop_duplicates(subset=None, keep='first', inplace=False, ignore_index=False)
df_vegetaux.insert(0,"Origine",'Végétaux',True)
df_pivot_vegetaux = df_vegetaux.pivot_table( index = ['Origine','Zone','Code zone','Année','Code Produit','Produit'], columns = ['Élément'], values = ['Valeur'])
df_pivot_vegetaux = df_pivot_vegetaux['Valeur'].reset_index()

indexdrop = df_animaux[df_animaux['Zone'] == 'Chine' ].index
df_animaux = df_animaux.drop(indexdrop , inplace=False)
df_animaux = df_animaux.drop_duplicates(subset = None, keep = 'first', inplace = False, ignore_index = False)
df_animaux.insert(0,"Origine",'Animaux',True)
df_pivot_animaux = df_animaux.pivot_table( index = ['Origine','Zone','Code zone','Année','Code Produit','Produit'], columns = ['Élément'], values = ['Valeur'])
df_pivot_animaux = df_pivot_animaux['Valeur'].reset_index()


df_japon = df_pivot_vegetaux.query("Zone == 'Japon' and Produit == 'Avoine'")
indexdrop_japon_avoine = df_pivot_vegetaux.query("Zone == 'Japon' and Produit == 'Avoine'").index
df_vegetaux = df_vegetaux.drop(indexdrop_japon_avoine,inplace = False)


df_pivot = pd.concat([df_pivot_vegetaux,df_pivot_animaux])





df_merge = df_population[['Zone','Valeur']]
df_merge = df_merge.rename(columns = {'Valeur':'Population (En Million)'}, inplace= False)
df_pivot_final = pd.merge(df_pivot, df_merge, on = 'Zone',how='inner')



df_pivot_final['Totale Disponibilité alimentaire en kcal'] = ''
df_pivot_final['Totale disponibilité alimentaire en protéines en kg'] = ''



total_dispo_ali = df_pivot_final['Disponibilité alimentaire (Kcal/personne/jour)'] * df_pivot_final['Population (En Million)']*1000*365
total_dispo_ali_proteine = df_pivot_final['Disponibilité de protéines en quantité (g/personne/jour)'] * df_pivot_final['Population (En Million)']*365

df_pivot_final['Totale Disponibilité alimentaire en kcal'] = total_dispo_ali
df_pivot_final['Totale disponibilité alimentaire en protéines en kg'] = total_dispo_ali_proteine

df_pivot_final['Ratio énergie/poids (en kcal/kg)'] = ''
total = df_pivot_final['Totale Disponibilité alimentaire en kcal'] / (df_pivot_final["Disponibilité alimentaire en quantité (kg/personne/an)"] * df_pivot_final['Population (En Million)'] * 1000)
df_pivot_final['Ratio énergie/poids (en kcal/kg)'] = total



df_pivot_ratio = df_pivot_final.pivot_table( index = ['Origine','Code Produit','Produit'], columns = ['Zone'], values = ['Ratio énergie/poids (en kcal/kg)'] )




df_pivot_ratio_final = df_pivot_ratio['Ratio énergie/poids (en kcal/kg)'].reset_index()

df_pivot_ratio_final['Ratio énergie/poids moyen'] = ''

  
df_pivot_ratio_final['Ratio énergie/poids moyen'] = df_pivot_ratio_final.mean( axis = 1)
 
    

df_ratio = df_pivot_ratio_final[['Origine','Code Produit','Produit','Ratio énergie/poids moyen']]

#Q4
print(df_ratio[df_ratio['Produit'] == 'Oeufs'])


df_pivot_final["Disponibilité alimentaire en quantité (kg)"]=""
total_quantité_en_kg = df_pivot_final['Disponibilité alimentaire en quantité (kg/personne/an)'] * df_pivot_final['Population (En Million)']*1000
df_pivot_final["Disponibilité alimentaire en quantité (kg)"] = total_quantité_en_kg
df_pivot_final['Pourcentage de protéines (%)'] = ''
ratio_proteine = df_pivot_final['Totale disponibilité alimentaire en protéines en kg'] / df_pivot_final["Disponibilité alimentaire en quantité (kg)"] * 100
df_pivot_final['Pourcentage de protéines (%)'] = ratio_proteine
               

df_pivot_ratio_proteine = df_pivot_final.pivot_table( index = ['Produit'], columns = ['Zone'], values = ['Pourcentage de protéines (%)'] )




df_pivot_ratio_final_proteine = df_pivot_ratio_proteine['Pourcentage de protéines (%)'].reset_index()

df_pivot_ratio_final_proteine['Pourcentage moyen en protéine (%)'] = ""


df_pivot_ratio_final_proteine['Pourcentage moyen en protéine (%)'] = df_pivot_ratio_final_proteine.mean(axis = 1)
df_merge_prot = df_pivot_ratio_final_proteine[['Produit','Pourcentage moyen en protéine (%)']]
df_ratio = pd.merge(df_ratio,df_merge_prot, on = 'Produit',how= 'outer')


print(df_ratio[df_ratio['Produit'] == 'Avoine']['Pourcentage moyen en protéine (%)'])

#Q5 

df_ratio = df_ratio.sort_values(by = 'Ratio énergie/poids moyen', ascending = False )
df_ratio[['Code Produit','Produit','Ratio énergie/poids moyen']].head()

df_ratio = df_ratio.sort_values(by = 'Pourcentage moyen en protéine (%)', ascending = False )
df_ratio[['Code Produit','Produit','Pourcentage moyen en protéine (%)']].head()

#Q6,Q7
df_pivot_dispo_int = df_pivot_final.pivot_table( index = ['Origine','Code Produit','Produit'], columns = ['Zone'], values = ["Disponibilité intérieure"] )
df_pivot_dispo_int = df_pivot_dispo_int["Disponibilité intérieure"].reset_index()          
df_pivot_dispo_int['Totale Disponibilité interieur en milliers de tonnes'] = ''


total_dispo_int = df_pivot_dispo_int.sum(axis=1)

df_pivot_dispo_int['Totale Disponibilité interieur en milliers de tonnes'] = total_dispo_int
df_pivot_court = df_pivot_dispo_int[['Code Produit','Totale Disponibilité interieur en milliers de tonnes']]

df_ratio = pd.merge(df_ratio,df_pivot_court, on = 'Code Produit',how = 'outer',right_index=True)


df_ratio['Disponibilité intérieur en kcal'] = "" 


total_dispo_int_kcal = df_ratio['Totale Disponibilité interieur en milliers de tonnes'] * df_ratio['Ratio énergie/poids moyen']*1000000
df_ratio['Disponibilité intérieur en kcal'] = total_dispo_int_kcal


total_dispo_int_mondiale_vegetaux_kcal = df_ratio[df_ratio['Origine']=='Végétaux']['Disponibilité intérieur en kcal'].sum()
nb_humain_nourri_2013 = total_dispo_int_mondiale_vegetaux_kcal / (2500*365)
df_ratio['Disponibilité intérieur en protéines (kg)'] = ''
dispo_int_mondiale_prot = df_ratio['Totale Disponibilité interieur en milliers de tonnes'] * 1000000 * (df_ratio['Pourcentage moyen en protéine (%)'] * 0.01)
df_ratio['Disponibilité intérieur en protéines (kg)'] = dispo_int_mondiale_prot
dispo_int_mondiale_proteine_vegetaux = df_ratio[df_ratio['Origine']=='Végétaux']['Disponibilité intérieur en protéines (kg)'].sum() 

nb_humain_nourri_valeur_prot = dispo_int_mondiale_proteine_vegetaux / (60*0.001*365)




nb_humain_pourcent = (nb_humain_nourri_2013 /pop_mondiale_2013 ) * 100

nb_humain_pourcent_prot =( nb_humain_nourri_valeur_prot /  pop_mondiale_2013) * 100

print(total_dispo_int_mondiale_vegetaux_kcal)
print(nb_humain_nourri_2013)
print(nb_humain_pourcent)

print(nb_humain_nourri_valeur_prot)
print(nb_humain_pourcent_prot)

#Q8
df_merge_aliment_pour_animaux = df_pivot_final.pivot_table(index = ['Produit'],columns = ['Zone'],values = ['Aliments pour animaux'])
df_merge_aliment_pour_animaux = df_merge_aliment_pour_animaux['Aliments pour animaux'].reset_index()
df_merge_aliment_pour_animaux['Total aliments pour animaux (En milliers de tonnes)(1)']=''
df_merge_aliment_pour_animaux['Total aliments pour animaux (En milliers de tonnes)(1)'] = df_merge_aliment_pour_animaux.sum(axis = 1)
df_merge_aliment_pour_animaux = df_merge_aliment_pour_animaux[['Produit','Total aliments pour animaux (En milliers de tonnes)(1)']]

df_merge_perte = df_pivot_final.pivot_table(index = ['Produit'],columns = ['Zone'],values = ['Pertes'])
df_merge_perte = df_merge_perte['Pertes'].reset_index()
df_merge_perte['Total pertes (en milliers de tonnes)(2)']=''
df_merge_perte['Total pertes (en milliers de tonnes)(2)']=df_merge_perte.sum(axis = 1)
df_merge_perte = df_merge_perte[['Produit','Total pertes (en milliers de tonnes)(2)']]

df_merge_nourriture = df_pivot_final.pivot_table(index = ['Produit'],columns = ['Zone'],values = ['Nourriture'])
df_merge_nourriture = df_merge_nourriture['Nourriture'].reset_index()
df_merge_nourriture['Total nourriture (en milliers de tonnes)(3)']=''
df_merge_nourriture['Total nourriture (en milliers de tonnes)(3)']=df_merge_nourriture.sum(axis = 1)
df_merge_nourriture = df_merge_nourriture[['Produit','Total nourriture (en milliers de tonnes)(3)']]


df_ratio = pd.merge(df_ratio,df_merge_aliment_pour_animaux,on='Produit',how='outer')
df_ratio = pd.merge(df_ratio,df_merge_perte, on = 'Produit',how = 'outer')
df_ratio = pd.merge(df_ratio,df_merge_nourriture, on = 'Produit',how = 'outer')



total_Q8 = (df_ratio["Total aliments pour animaux (En milliers de tonnes)(1)"]*1000000 + df_ratio['Total pertes (en milliers de tonnes)(2)']*1000000 + df_ratio['Total nourriture (en milliers de tonnes)(3)']*1000000)    
df_ratio['Total 1+2+3 en kcal']= ''
total_Q8_kcal = total_Q8 * df_ratio['Ratio énergie/poids moyen']  
df_ratio['Total 1+2+3 en kcal'] = total_Q8_kcal

total_Q8_vegetaux = df_ratio[df_ratio['Origine']=='Végétaux']['Total 1+2+3 en kcal'].sum()

       
         
nb_humain_nourri_avec_total_Q8 = total_Q8_vegetaux / (2500*365)

total_Q8_prot = total_Q8 * (df_ratio['Pourcentage moyen en protéine (%)'] / 100)
df_ratio['Total 1+2+3 en proteine (kg)']=''
df_ratio['Total 1+2+3 en proteine (kg)'] = total_Q8_prot

nb_humain_Q8_prot = df_ratio[df_ratio['Origine'] == 'Végétaux']['Total 1+2+3 en proteine (kg)'].sum()  / (60*0.001*365)
nb_humain_pourcent_Q8_kcal = (nb_humain_nourri_avec_total_Q8 / pop_mondiale_2013)*100
nb_humain_pourcent_Q8_Prot = (nb_humain_Q8_prot /pop_mondiale_2013)*100

print(nb_humain_nourri_avec_total_Q8)
print(nb_humain_Q8_prot)

print(nb_humain_pourcent_Q8_kcal)
print(nb_humain_pourcent_Q8_Prot)

#Q9
dispo_ali_mondiale = df_pivot_final["Nourriture"].sum()*1000000
nb_humain_Q9 = (dispo_ali_mondiale * df_ratio['Ratio énergie/poids moyen'].mean()) / (2500*365)
nb_humain_Q9_prot = dispo_ali_mondiale * (df_ratio['Pourcentage moyen en protéine (%)'].mean() / 100)/ ((60/1000)*365)
nb_humain_Q9_pourcent = (nb_humain_Q9 /pop_mondiale_2013)*100
nb_humain_Q9_prot_pourcent = (nb_humain_Q9_prot /pop_mondiale_2013)*100


print(nb_humain_Q9)
print(nb_humain_Q9_prot)
print(nb_humain_Q9_pourcent)
print(nb_humain_Q9_prot_pourcent)

#Q10
import pandas as pd

filepath4 = 'C:/Users/HP/Desktop/P3_NGUYEN_Quoc Vuong/FAO_2013_fr/fr_sousalimentation.csv'

df_sousalimentation = pd.read_csv(filepath4)

import numpy as np



df_sousalimentation = df_sousalimentation[df_sousalimentation['Zone'] != 'Chine' ]
df_sousalimentation = df_sousalimentation.replace({'Valeur':'<0.1'}, value = 0.1, method = 'pad')
df_sousalimentation = df_sousalimentation.replace(0,np.nan)
df_sousalimentation.astype({'Valeur': 'float'}).dtypes
df_sousalimentation['Valeur'] = pd.to_numeric(df_sousalimentation['Valeur'])





total_popu_sousalimenté = df_sousalimentation[df_sousalimentation['Année']=="2012-2014"]['Valeur'].sum() * 1000000
pourcentage_sousalimenté = (total_popu_sousalimenté/pop_mondiale_2013)*100
print(pourcentage_sousalimenté)


#Q11



df_cereales = df_cereales.drop_duplicates(subset=None, keep='first', inplace=False, ignore_index=False)
df_pivot_cereales = df_cereales.pivot_table( index = ['Zone','Code Produit','Produit'], columns = ['Élément'], values = ['Valeur'])
df_pivot_cereales = df_pivot_cereales['Valeur'].reset_index()

df_produit_cereale = df_pivot_cereales[['Code Produit']].drop_duplicates(subset=None, keep='first', inplace=False, ignore_index=False)
df_produit_cereale = df_produit_cereale[['Code Produit']]


df_produit_cereale.insert(0,'Test céréale','is_cereal',True)

df_tous_produits = pd.merge(df_pivot,df_produit_cereale,on = 'Code Produit', how = 'outer')
df_tous_produits

df_nourriture = df_tous_produits.pivot_table(index = ['Origine','Test céréale','Produit'], columns = ['Zone'], values = ['Nourriture'])
df_nourriture = df_nourriture['Nourriture'].reset_index()
df_nourriture_cerale = df_nourriture[df_nourriture['Test céréale']=='is_cereal']
df_nourriture_cerale['Total nourriture en kg'] = df_nourriture_cerale.sum(axis=1)*1000000

df_aliment_pour_animaux = df_tous_produits.pivot_table(index = ['Origine','Test céréale','Produit'], columns = ['Zone'], values = ["Aliments pour animaux"])
df_aliment_pour_animaux = df_aliment_pour_animaux['Aliments pour animaux'].reset_index()
df_aliment_pour_animaux_cerale = df_aliment_pour_animaux[df_aliment_pour_animaux['Test céréale']=='is_cereal']
df_aliment_pour_animaux_cerale['Total Aliments pour animaux en kg'] = df_aliment_pour_animaux_cerale.sum(axis=1)*1000000

total_nourriture_cereal = df_nourriture_cerale['Total nourriture en kg'].sum()
total_aliment_animaux_cereal = df_aliment_pour_animaux_cerale['Total Aliments pour animaux en kg'].sum()
total_nourriture_cereal
total_aliment_animaux_cereal

#12




total_popu_sousalimenté = df_sousalimentation[df_sousalimentation['Année']=="2012-2014"]['Valeur'].sum() * 1000000
pourcentage_sousalimenté = (total_popu_sousalimenté/pop_mondiale_2013)*100

df_pivot_sousalimentation = df_sousalimentation.pivot_table(index = ['Zone'], columns = ['Année'], values = ['Valeur'])

df_pivot_sousalimentation = df_pivot_sousalimentation['Valeur'].reset_index()
df_pivot_sousalimentation.insert(1,'Pays sous alimenté','est_sous_alimenté',True)
df_pivot_sousalimentation = df_pivot_sousalimentation[['Zone','Pays sous alimenté']]
df_all_table_sousali = pd.merge(df_pivot,df_pivot_sousalimentation, on='Zone', how = 'inner')

df_all_table_sousali = df_all_table_sousali[df_all_table_sousali['Origine']=='Végétaux']
df_all_table_sousali = df_all_table_sousali.groupby(['Code Produit','Produit'],as_index=False).sum()
df_all_table_sousali = df_all_table_sousali.sort_values(by = 'Exportations - Quantité',ascending = False)
df_top_15_produit_exp = df_all_table_sousali.head(15)


import pandas as pd
filepath = 'C:/Users/HP/Desktop/P3_NGUYEN_Quoc Vuong/FAO_2013_fr/fr_population.csv'
filepath1 = 'C:/Users/HP/Desktop/P3_NGUYEN_Quoc Vuong/FAO_2013_fr/fr_vegetaux.csv'

df_population = pd.read_csv(filepath)
df_vegetaux = pd.read_csv(filepath1)


import numpy as np
df_population = df_population.replace(0,np.nan)
df_vegetaux = df_vegetaux.replace(0, np.nan)


indexdrop = df_vegetaux[df_vegetaux['Zone'] == 'Chine' ].index
df_vegetaux = df_vegetaux.drop(indexdrop , inplace=False)
df_vegetaux = df_vegetaux.drop_duplicates(subset=None, keep='first', inplace=False, ignore_index=False)
df_vegetaux.insert(0,"Origine",'Végétaux',True)
df_pivot_vegetaux = df_vegetaux.pivot_table( index = ['Origine','Zone','Code Produit','Produit'], columns = ['Élément'], values = ['Valeur'])
df_pivot_vegetaux = df_pivot_vegetaux['Valeur'].reset_index()

df_top_15_merge = df_top_15_produit_exp[['Code Produit']]
df_top_200 = pd.merge(df_pivot_vegetaux,df_top_15_merge,on='Code Produit',how = 'inner')
df_top_200 = df_top_200.sort_values( by = "Importations - Quantité", ascending = False)

df_top_200_groupé = df_top_200.groupby(['Code Produit','Produit'], as_index = False).sum()
df_top_200_groupé

df_top_200_groupé = df_top_200.groupby(['Code Produit','Produit'], as_index = False).sum()
df_top_200_groupé['Ratio Other uses/Disponibilité inérieur']= df_top_200_groupé['Autres utilisations (non alimentaire)']/df_top_200_groupé['Disponibilité intérieure']
df_top_200_groupé['Ratio Nourriture animale/Nourriture totale']= df_top_200_groupé['Aliments pour animaux']/(df_top_200_groupé['Aliments pour animaux']+df_top_200_groupé['Nourriture'])
df_top_3_ratio1 = df_top_200_groupé.sort_values(by = 'Ratio Other uses/Disponibilité inérieur', ascending = False)
df_top_3_Ratio1 = df_top_3_ratio1.head(3)
df_top_3_Ratio2 = df_top_200_groupé.sort_values(by = 'Ratio Nourriture animale/Nourriture totale', ascending = False)
df_top_3_Ratio2 = df_top_3_Ratio2.head(3)
df_top_3_Ratio1_result = df_top_3_Ratio1[['Code Produit','Produit','Ratio Other uses/Disponibilité inérieur']]
df_top_3_Ratio1_result

df_top_3_Ratio2_result = df_top_3_Ratio2[['Code Produit','Produit','Ratio Nourriture animale/Nourriture totale']]
df_top_3_Ratio2_result

#Q13
df_tous_produits_USA = df_tous_produits[df_tous_produits['Zone']== "États-Unis d'Amérique"]
df_tous_produits_USA_cereal = df_tous_produits_USA[df_tous_produits_USA['Test céréale']== 'is_cereal']
total_aliment_pour_animaux_cereal_USA = df_tous_produits_USA_cereal['Aliments pour animaux'].sum()
qté_libéré_cereale = total_aliment_pour_animaux_cereal_USA * 0.1*1000
qté_libéré_cereale


#Q14

df_tous_produits_Thai = df_tous_produits[df_tous_produits['Zone']== "Thaïlande"]

df_tous_produits_Thai_manioc = df_tous_produits_Thai[df_tous_produits_Thai['Produit']== 'Manioc']
qté_manioc_exporté = df_tous_produits_Thai_manioc['Exportations - Quantité']
total_prod_manioc = df_tous_produits_Thai_manioc['Production'].sum()
exp_manioc_en_proportion = qté_manioc_exporté/total_prod_manioc*100
exp_manioc_en_proportion

pers_sous_alimenté_thai = df_sousalimentation.query("Zone=='Thaïlande' and Année=='2012-2014'")['Valeur']*1000000
pop_totale_Thai = df_population[df_population['Zone']=='Thaïlande']['Valeur'] * 1000
taux_sous_nutrition = pers_sous_alimenté_thai / float(pop_totale_Thai) * 100
taux_sous_nutrition

#Q15
import pandas as pd
population = df_population[['Zone','Code zone','Année','Valeur']]
population = population.rename( columns = {'Zone':'pays','Code zone':'code_pays','Année':'année','Valeur':'population'}, inplace = False)
import pymysql.cursors
connection = pymysql.connect(host='localhost',
                             user='user',
                             password='AAA',
                             database='my_data.db',
                             cursorclass=pymysql.cursors.DictCursor)

with connection:
    with connection.cursor() as cursor:
  
   
   
    #Creation
    population.to_sql('population', cursor, if_exists='replace', index = False)

import mysql.connector
conn = mysql.connector.connect(database="projet_3")
c = conn.cursor()
conn.close()

#Clé primaire : code_pays, pays
pd.read_sql("ALTER TABLE population ADD PRIMARY KEY (code_pays,pays)",conn)



dispo_alim = df_tous_produits[['Zone','Code zone','Année','Produit','Code Produit','Origine','Disponibilité alimentaire en quantité (kg/personne/an)','Disponibilité alimentaire (Kcal/personne/jour)','Disponibilité de protéines en quantité (g/personne/jour)','Disponibilité de matière grasse en quantité (g/personne/jour)']]
df_merge_popu = df_population[['Code zone','Valeur']]
dispo_alim = pd.merge( dispo_alim, df_merge_popu, on = 'Code zone',how = 'outer')
dispo_alim['Disponibilité alimentaire en quantité (kg/personne/an)'] = dispo_alim['Disponibilité alimentaire en quantité (kg/personne/an)'] * dispo_alim['Valeur'] * 1000
dispo_alim = dispo_alim.rename( columns = {'Zone':'pays','Code zone':'code_pays','Année':'année','Produit':'produit','Code Produit':'code_produit','Origine':'origin','Disponibilité alimentaire en quantité (kg/personne/an)':'dispo_alim_tonnes','Disponibilité alimentaire (Kcal/personne/jour)':'dispo_alim_kcal_p_j','Disponibilité de protéines en quantité (g/personne/jour)':'dispo_prot','Disponibilité de matière grasse en quantité (g/personne/jour)':'dispo_mat_gr'}, inplace= False)
dispo_alim = dispo_alim.drop(columns = 'Valeur',inplace = False)

'''c.execute( 'CREATE TABLE dispo_alim (pays TEXT, code_pays INTEGER, année INTEGER,produit TEXT,code_produit INTEGER,origin TEXT,))'''
dispo_alim.to_sql('dispo_alim', conn, if_exists='append', index = False)


#Q16

equilibre_prod = df_tous_produits[['Zone','Code zone','Année','Produit','Code Produit','Disponibilité intérieure','Aliments pour animaux','Semences','Pertes','Traitement','Nourriture','Autres utilisations (non alimentaire)']]
equilibre_prod = equilibre_prod.rename( columns = {'Zone':'pays','Code zone':'code_pays','Année':'année','Produit':'produit','Code Produit':'code_produit','Disponibilité intérieure':'dispo_int','Aliments pour animaux':'alim_ani','Semences':'semences','Pertes':'pertes','Traitement':'transfo','Nourriture':'nourriture','Autres utilisations (non alimentaire)':'autres_utilisations'})
equilibre_prod.to_sql('equilibre_prod', conn, if_exists = 'append',index = False)

#Q17
sous_nutrition = df_sousalimentation[df_sousalimentation['Année']=="2012-2014"]
sous_nutrition = sous_nutrition[['Zone', 'Code zone','Valeur']]

sous_nutrition.insert(2,'année',2013,True)

sous_nutrition = sous_nutrition.rename( columns = {'Zone':'pays', 'Code zone':'code_pays','Valeur':'nb_personnes'})
sous_nutrition.to_sql('sous_nutrition', conn, if_exists = 'append', index = False)

pd.read_sql( 'SELECT * FROM dispo_alim ORDER BY dispo_prot DESC LIMIT 10',conn)
pd.read_sql( 'SELECT * FROM dispo_alim ORDER BY dispo_alim_kcal_p_j DESC LIMIT 10', conn)

